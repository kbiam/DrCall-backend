const express = require('express');
const router = express.Router();
const db = require('../config/db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const JWT_SECRET = "maitri";

// Middleware to verify token
function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(403).json({ message: "No token provided" });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid token" });
  }
}

// Get user profile
router.get("/profile", verifyToken, (req, res) => {
    console.log(req.user)
  db.query("SELECT id, name, email, role FROM users WHERE id = ?", 
    [req.user.id], (err, results) => {
      if (err || results.length === 0) {
        return res.status(402).json({ message: "User not found" });
      }
      console.log(results[0])
      res.json(results[0]);
    });
});

module.exports = router