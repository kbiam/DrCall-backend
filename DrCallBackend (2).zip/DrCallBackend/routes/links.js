const express = require('express');
const router = express.Router();
const db = require('../config/db');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const JWT_SECRET = "maitri";

// Middleware to verify token
function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(403).json({ message: "No token provided" });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid token" });
  }
}

// Create the links table if it doesn't exist
function ensureLinksTable(db) {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS meeting_links (
      id INT AUTO_INCREMENT PRIMARY KEY,
      doctor_id INT NOT NULL,
      unique_id VARCHAR(16) NOT NULL,
      duration INT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (doctor_id) REFERENCES users(id)
    )
  `;
  
  db.query(createTableQuery, (err) => {
    if (err) {
      console.error("Failed to create meeting_links table:", err);
    }
  });
}

// Run this when the server starts
ensureLinksTable(db);

// Generate a new link
router.post("/generate", verifyToken, (req, res) => {
  // Check if user is a doctor
  if (req.user.role !== 'doctor') {
    return res.status(403).json({ message: "Only doctors can generate links" });
  }
  
  const { duration } = req.body;
  const doctorId = req.user.id;
  
  // Generate unique ID for the link
  const uniqueId = crypto.randomBytes(8).toString('hex');
  
  // Store the link in database
  db.query(
    "INSERT INTO meeting_links (doctor_id, unique_id, duration) VALUES (?, ?, ?)",
    [doctorId, uniqueId, duration],
    (err, result) => {
      if (err) return res.status(500).json({ message: "Failed to generate link", error: err });
      
      // Construct the link
      const link = `http://localhost:5173/meet/${doctorId}/${uniqueId}?duration=${duration}`;
      
      res.json({ 
        message: "Link generated successfully",
        link: link,
        id: result.insertId
      });
    }
  );
});

// Get recent links for a doctor
router.get("/recent", verifyToken, (req, res) => {
  // Check if user is a doctor
  if (req.user.role !== 'doctor') {
    return res.status(403).json({ message: "Access denied" });
  }
  
  db.query(
    `SELECT id, doctor_id, unique_id, duration, created_at FROM meeting_links 
    WHERE doctor_id = ? ORDER BY created_at DESC LIMIT 10`,
    [req.user.id],
    (err, results) => {
      if (err) return res.status(500).json({ message: "Failed to fetch links", error: err });
      
      // Format links
      const formattedLinks = results.map(link => ({
        id: link.id,
        link: `http://localhost:5173/meet/${link.doctor_id}/${link.unique_id}?duration=${link.duration}`,
        duration: link.duration,
        created_at: link.created_at
      }));
      
      res.json(formattedLinks);
    }
  );
});

module.exports = router;