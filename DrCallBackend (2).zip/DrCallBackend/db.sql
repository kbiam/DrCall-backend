create database drcall;
use drcall;

-- Users table (for both doctors and patients)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    role ENUM('doctor', 'patient'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Appointments or Call Logs
CREATE TABLE calls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    doctor_id INT,
    patient_id INT,
    scheduled_at DATETIME,
    call_status ENUM('scheduled', 'completed', 'missed') DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES users(id),
    FOREIGN KEY (patient_id) REFERENCES users(id)
);

-- Optional: Messages or Prescriptions
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    call_id INT,
    sender_id INT,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (call_id) REFERENCES calls(id),
    FOREIGN KEY (sender_id) REFERENCES users(id)
);
select * from calls;