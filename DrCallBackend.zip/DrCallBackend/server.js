const app = require('./app');
const authRoute = require("./routes/auth");
const callRoute = require("./routes/call");
const linksRoute = require("./routes/links")
const usersRoute = require("./routes/users")
const PORT = process.env.PORT || 5000;
const db = require('./config/db');

app.use("/auth", authRoute);
app.use("/call", callRoute);
app.use('/links', linksRoute);
app.use('/users', usersRoute);


app.get('/doctors/:linkId', (req, res) => {
    const { linkId } = req.params;
    
    db.query(
      `SELECT u.id, u.name, ml.duration
       FROM users u
       JOIN meeting_links ml ON u.id = ml.doctor_id
       WHERE ml.unique_id = ?`,
      [linkId],
      (err, results) => {
        if (err || results.length === 0) {
          return res.status(404).json({ message: "Invalid link or doctor not found" });
        }
        
        res.json({
          doctor: {
            id: results[0].id,
            name: results[0].name
          },
          duration: results[0].duration
        });
      }
    );
  });


app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
