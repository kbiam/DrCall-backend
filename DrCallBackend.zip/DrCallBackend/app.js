var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var dotenv = require('dotenv')
const session = require("express-session");
const passport = require("passport");
const cors = require("cors")
require("./config/auth")

var app = express();
app.use(cors())

dotenv.config()

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(
    session({
      secret: "ksuh",
      resave: false,
      saveUninitialized: true,
    })
  );

app.use(passport.initialize());
app.use(passport.session());


app.get("/", (req, res) => {
  res.send("API is running...");
});

module.exports = app;
