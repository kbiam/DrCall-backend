const express = require('express');
const router = express.Router();
const db = require('../config/db');
const jwt = require('jsonwebtoken');

const JWT_SECRET = "maitri";

// Middleware to verify token
function verifyToken(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(403).json({ message: "No token provided" });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid token" });
  }
}

// Get all calls for a doctor
router.get("/doctor", verifyToken, (req, res) => {
  // Check if user is a doctor
  if (req.user.role !== 'doctor') {
    return res.status(403).json({ message: "Access denied" });
  }
  
  const query = `
    SELECT c.*, u.name as patient_name
    FROM calls c
    JOIN users u ON c.patient_id = u.id
    WHERE c.doctor_id = ?
    ORDER BY c.scheduled_at ASC
  `;
  
  db.query(query, [req.user.id], (err, results) => {
    if (err) return res.status(500).json({ message: "Failed to fetch appointments", error: err });
    res.json(results);
  });
});

// Schedule a call (for logged-in users)
router.post("/schedule", verifyToken, (req, res) => {
  const { doctor_id, scheduled_at } = req.body;
  const patient_id = req.user.id;
  
  // Convert ISO datetime to MySQL format
  const mysqlDatetime = new Date(scheduled_at)
    .toISOString()
    .slice(0, 19)
    .replace('T', ' ');
  
  // Verify doctor exists
  db.query("SELECT id FROM users WHERE id = ? AND role = 'doctor'", 
    [doctor_id], (err, results) => {
      if (err || results.length === 0) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      // Create the appointment with formatted datetime
      db.query("INSERT INTO calls (doctor_id, patient_id, scheduled_at) VALUES (?, ?, ?)",
        [doctor_id, patient_id, mysqlDatetime], (err, result) => {
          if (err) { 
            console.log(err); 
            return res.status(500).json({ message: "Failed to schedule call", error: err });
          }
          res.json({ 
            message: "Call scheduled successfully",
            call_id: result.insertId
          });
        });
    });
});
// NEW ROUTE: Schedule a call for guest (non-authenticated users)
router.post("/guest-schedule", (req, res) => {
  const { doctor_id, name, email, scheduled_at } = req.body;
  
  console.log(req.body)
  // Validate required fields
  if (!doctor_id || !name || !email || !scheduled_at) {
    return res.status(400).json({ message: "Missing required fields" });
  }
  
  // Verify doctor exists
  db.query("SELECT id FROM users WHERE id = ? AND role = 'doctor'", 
    [doctor_id], (err, results) => {
      if (err || results.length === 0) {
        return res.status(404).json({ message: "Doctor not found" });
      }
      
      // First, check if a user with this email exists
      db.query("SELECT id FROM users WHERE email = ?", [email], (err, users) => {
        if (err) {
          return res.status(500).json({ message: "Database error", error: err });
        }
        
        // If user exists, use their ID
        if (users.length > 0) {
          const patient_id = users[0].id;
          createAppointment(patient_id);
        } else {
          // Create a new user with patient role
          db.query(
            "INSERT INTO users (name, email, role) VALUES (?, ?, 'patient')",
            [name, email],
            (err, result) => {
              if (err) {
                return res.status(500).json({ message: "Failed to create user", error: err });
              }
              
              const patient_id = result.insertId;
              createAppointment(patient_id);
            }
          );
        }
      });
      
      // Helper function to create the appointment
      function createAppointment(patient_id) {
        db.query(
          "INSERT INTO calls (doctor_id, patient_id, scheduled_at) VALUES (?, ?, ?)",
          [doctor_id, patient_id, scheduled_at],
          (err, result) => {
            if (err) {
              return res.status(500).json({ message: "Failed to schedule call", error: err });
            }
            
            res.json({
              message: "Call scheduled successfully",
              call_id: result.insertId
            });
          }
        );
      }
    });
});

// Update call status
router.put("/:id/status", verifyToken, (req, res) => {
  const { status } = req.body;
  const callId = req.params.id;
  
  // Verify valid status
  if (!['scheduled', 'completed', 'missed'].includes(status)) {
    return res.status(400).json({ message: "Invalid status" });
  }
  
  // Update call status
  db.query("UPDATE calls SET call_status = ? WHERE id = ?",
    [status, callId], (err, result) => {
      if (err) return res.status(500).json({ message: "Failed to update call status", error: err });
      
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Call not found" });
      }
      
      res.json({ message: "Call status updated successfully" });
    });
});

// Add notes to a call
router.post("/:id/notes", verifyToken, (req, res) => {
  const { notes } = req.body;
  const callId = req.params.id;
  
  // Update call notes
  db.query("UPDATE calls SET notes = ? WHERE id = ?",
    [notes, callId], (err, result) => {
      if (err) return res.status(500).json({ message: "Failed to add notes", error: err });
      
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Call not found" });
      }
      
      res.json({ message: "Notes added successfully" });
    });
});

module.exports = router;